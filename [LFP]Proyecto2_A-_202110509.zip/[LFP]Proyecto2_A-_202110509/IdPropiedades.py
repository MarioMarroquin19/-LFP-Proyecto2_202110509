class ID_Propiedades:
    def __init__(self, Id_propiedades):
        self.Id_propiedades = Id_propiedades

    def __str__(self):
        return str(self.Id_propiedades)