class ImprimirID:
    def __init__(self, ImprimirID):
        self.ImprimirID = ImprimirID

    def __str__(self):
        return str(self.ImprimirID)