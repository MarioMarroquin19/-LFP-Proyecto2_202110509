class Propiedades:
    def __init__(self, propiedades):
        self.propiedades = propiedades
    
    def __str__(self):
        return str(self.propiedades)