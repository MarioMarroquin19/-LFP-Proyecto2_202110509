class ID:
    def __init__(self, id):
        self.id = id

    def __str__(self):
        return str(self.id)