class Control:
    def __init__(self, control):
        self.control = control
    
  

    
    def __str__(self):
        return str(self.control)