class ID_Colocacion:
    def __init__(self, Id_colocacion):
        self.Id_colocacion = Id_colocacion
    
    def __str__(self):
        return str(self.Id_colocacion)