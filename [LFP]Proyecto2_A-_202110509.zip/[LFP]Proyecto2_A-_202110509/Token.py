class Token:
    def __init__(self, fila, columna, lexema):
        self.fila = fila
        self.columna = columna
        self.lexema = lexema