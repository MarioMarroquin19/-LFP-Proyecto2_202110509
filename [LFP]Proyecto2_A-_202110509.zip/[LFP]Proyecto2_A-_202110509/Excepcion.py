class Excepcion:
    def __init__(self, fila, columna,error) :
        self.fila = fila
        self.columna = columna
        #self.tipo = tipo
        self.error = error