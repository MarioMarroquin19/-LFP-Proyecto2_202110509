class Colocacion:
    def __init__(self, colocacion):
        self.colocacion = colocacion
    
    def __str__(self):
        return str(self.colocacion)