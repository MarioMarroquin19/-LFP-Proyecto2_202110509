class caracCol:
    def __init__(self, caracCol):
        self.caracCol = caracCol
    
    def __str__(self):
        return str(self.caracCol)