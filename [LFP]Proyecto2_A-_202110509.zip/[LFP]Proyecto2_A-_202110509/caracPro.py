class caracPro:
    def __init__(self, caracPro):
        self.caracPro = caracPro
    
    def __str__(self):
        return str(self.caracPro)